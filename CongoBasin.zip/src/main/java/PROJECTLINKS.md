Put external links here:
https://app.milanote.com/1RCPAr1CRfqRa0?p=0SQ0phrtTcR
GitHub Rep:
https://github.com/Potato21W/test1
Flow chart:
https://lucid.app/lucidspark/9ea83c77-a52b-4bad-b331-816815ceec9f/edit?viewport_loc=-1949%2C-1198%2C5657%2C3964%2C0_0&invitationId=inv_96708e46-b241-4db1-92e3-100c4402c35c

Copy of lucid:
https://lucid.app/lucidspark/d674a17a-886f-4a05-b671-32e2fa018f74/edit?viewport_loc=-6361%2C458%2C11885%2C8328%2C0_0&invitationId=inv_d8680360-98d7-492f-a6b1-7d17f95776bf


SQL references
https://www.geeksforgeeks.org/establishing-jdbc-connection-in-java/
https://www.geeksforgeeks.org/introduction-to-jdbc/
https://docs.oracle.com/javase/8/docs/api/
https://www.w3schools.com/sql/sql_insert.asp